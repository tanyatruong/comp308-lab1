import { useContext } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import AuthContext from '../context/AuthContext';

const AdminRoute = () => {
    const { user } = useContext(AuthContext);
    return user?.email === "admin@mycentennialcollege.ca" ? 
        <Outlet /> : 
        <Navigate to="/dashboard" replace />;
};

export default AdminRoute;