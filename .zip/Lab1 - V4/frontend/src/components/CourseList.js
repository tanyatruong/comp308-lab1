import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import AuthContext from '../context/AuthContext';
import { Container, Table, Button, Alert, Card, Modal, Form } from 'react-bootstrap';

const CourseList = () => {
    const [courses, setCourses] = useState([]);
    const [myCourses, setMyCourses] = useState([]);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const { user } = useContext(AuthContext);
    const isAdmin = user?.email === "admin@mycentennialcollege.ca";
    
    // Modal states
    const [showEditModal, setShowEditModal] = useState(false);
    const [editingCourse, setEditingCourse] = useState(null);
    const [availableSections, setAvailableSections] = useState([]);

    // Fetch functions
    const fetchAllCourses = async () => {
        try {
            const res = await axios.get('http://localhost:5000/api/courses', { 
                withCredentials: true 
            });
            setCourses(res.data);
        } catch (err) {
            setError('Error fetching courses');
        }
    };

    const fetchMyCourses = async () => {
        try {
            const res = await axios.get('http://localhost:5000/api/courses/my-courses', { 
                withCredentials: true 
            });
            setMyCourses(res.data);
        } catch (err) {
            setError('Error fetching your courses');
        }
    };

    const fetchAvailableCourses = async () => {
        try {
            const res = await axios.get('http://localhost:5000/api/courses', { 
                withCredentials: true 
            });
            setCourses(res.data);
        } catch (err) {
            setError('Error fetching available courses');
        }
    };

    useEffect(() => {
        if (isAdmin) {
            fetchAllCourses();
        } else {
            fetchMyCourses();
            fetchAvailableCourses();
        }
    }, [isAdmin]);

    // Handle functions
    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this course?')) {
            try {
                await axios.delete(`http://localhost:5000/api/courses/${id}`, { 
                    withCredentials: true 
                });
                setCourses(courses.filter(course => course._id !== id));
                setSuccess('Course deleted successfully');
            } catch (err) {
                setError('Error deleting course');
            }
        }
    };

    const handleDrop = async (courseId) => {
        if (window.confirm('Are you sure you want to drop this course?')) {
            try {
                await axios.put(`http://localhost:5000/api/courses/${courseId}/drop`, {}, { 
                    withCredentials: true 
                });
                setSuccess('Successfully dropped course');
                fetchMyCourses();
                fetchAvailableCourses();
            } catch (err) {
                setError('Error dropping course');
            }
        }
    };

    const handleEnroll = async (courseId) => {
        try {
            await axios.put(`http://localhost:5000/api/courses/${courseId}/enroll`, {}, {
                withCredentials: true
            });
            setSuccess('Successfully enrolled in course');
            fetchMyCourses();
            fetchAvailableCourses();
        } catch (err) {
            setError('Error enrolling in course');
        }
    };
    
    const handleEditClick = async (course) => {
        setEditingCourse(course);
        if (!isAdmin) {
            try {
                const response = await axios.get(
                    `http://localhost:5000/api/courses/sections/${course.courseCode}`,
                    { withCredentials: true }
                );
                setAvailableSections(response.data);
            } catch (err) {
                setError('Error fetching course sections');
            }
        }
        setShowEditModal(true);
    };

    const handleUpdate = async (e) => {
        e.preventDefault();
        try {
            if (isAdmin) {
                await axios.put(
                    `http://localhost:5000/api/courses/${editingCourse._id}`,
                    editingCourse,
                    { withCredentials: true }
                );
            } else {
                await axios.put(
                    `http://localhost:5000/api/courses/${editingCourse._id}/section`,
                    { section: editingCourse.section },
                    { withCredentials: true }
                );
            }
            setSuccess('Course updated successfully');
            setShowEditModal(false);
            if (isAdmin) {
                fetchAllCourses();
            } else {
                fetchMyCourses();
            }
        } catch (err) {
            setError('Error updating course');
        }
    };

    const handleInputChange = (e) => {
        setEditingCourse({
            ...editingCourse,
            [e.target.name]: e.target.value
        });
    };

    // Modal component
    const EditModal = () => (
        <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
            <Modal.Header closeButton>
                <Modal.Title>
                    {isAdmin ? 'Edit Course' : 'Change Section'}
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form onSubmit={handleUpdate}>
                    {isAdmin ? (
                        <>
                            <Form.Group className="mb-3">
                                <Form.Label>Course Code</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="courseCode"
                                    value={editingCourse?.courseCode || ''}
                                    onChange={handleInputChange}
                                    required
                                />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Label>Course Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="courseName"
                                    value={editingCourse?.courseName || ''}
                                    onChange={handleInputChange}
                                    required
                                />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Label>Section</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="section"
                                    value={editingCourse?.section || ''}
                                    onChange={handleInputChange}
                                />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Label>Semester</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="semester"
                                    value={editingCourse?.semester || ''}
                                    onChange={handleInputChange}
                                />
                            </Form.Group>
                        </>
                    ) : (
                        <Form.Group className="mb-3">
                            <Form.Label>Section</Form.Label>
                            <Form.Select
                                name="section"
                                value={editingCourse?.section || ''}
                                onChange={handleInputChange}
                                required
                            >
                                <option value="">Select a section</option>
                                {availableSections.map((section, index) => (
                                    <option key={index} value={section.section}>
                                        {section.section}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                    )}
                    <div className="d-flex justify-content-end gap-2">
                        <Button variant="secondary" onClick={() => setShowEditModal(false)}>
                            Cancel
                        </Button>
                        <Button variant="primary" type="submit">
                            Save Changes
                        </Button>
                    </div>
                </Form>
            </Modal.Body>
        </Modal>
    );

    // Admin view
    if (isAdmin) {
        return (
            <Container className="mt-4">
                <h2 className="text-center">Course Management</h2>
                {error && <Alert variant="danger">{error}</Alert>}
                {success && <Alert variant="success">{success}</Alert>}
                
                <Card className="p-4 shadow-sm">
                    <Card.Body>
                        <div className="d-flex justify-content-between mb-3">
                            <h4>All Courses</h4>
                            <Link to="/courses/add">
                                <Button variant="primary">Add New Course</Button>
                            </Link>
                        </div>
                        <Table striped bordered hover responsive>
                            <thead>
                                <tr>
                                    <th>Course Code</th>
                                    <th>Course Name</th>
                                    <th>Section</th>
                                    <th>Semester</th>
                                    <th>Enrolled Students</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {courses.map(course => (
                                    <tr key={course._id}>
                                        <td>{course.courseCode}</td>
                                        <td>{course.courseName}</td>
                                        <td>{course.section}</td>
                                        <td>{course.semester}</td>
                                        <td>{course.students?.length || 0}</td>
                                        <td>
                                            <Link to={`/courses/${course._id}/students`}>
                                                <Button variant="info" size="sm" className="me-2">
                                                    View
                                                </Button>
                                            </Link>
                                            <Button
                                                variant="warning"
                                                size="sm"
                                                className="me-2"
                                                onClick={() => handleEditClick(course)}
                                            >
                                                Edit
                                            </Button>
                                            <Button
                                                variant="danger"
                                                size="sm"
                                                onClick={() => handleDelete(course._id)}
                                            >
                                                Delete
                                            </Button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    </Card.Body>
                </Card>
                <EditModal />
            </Container>
        );
    }

    // Student view
    return (
        <Container className="mt-4">
            <h2 className="text-center">Course Management</h2>
            {error && <Alert variant="danger">{error}</Alert>}
            {success && <Alert variant="success">{success}</Alert>}

            <Card className="p-4 shadow-sm mb-4">
                <Card.Body>
                    <h4>My Enrolled Courses</h4>
                    <Table striped bordered hover responsive>
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Section</th>
                                <th>Semester</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {myCourses.map(course => (
                                <tr key={course._id}>
                                    <td>{course.courseCode}</td>
                                    <td>{course.courseName}</td>
                                    <td>{course.section}</td>
                                    <td>{course.semester}</td>
                                    <td>
                                        <Button
                                            variant="warning"
                                            size="sm"
                                            className="me-2"
                                            onClick={() => handleEditClick(course)}
                                        >
                                            Change Section
                                        </Button>
                                        <Button
                                            variant="danger"
                                            size="sm"
                                            onClick={() => handleDrop(course._id)}
                                        >
                                            Drop
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </Card.Body>
            </Card>

            <Card className="p-4 shadow-sm">
                <Card.Body>
                    <h4>Available Courses</h4>
                    <Table striped bordered hover responsive>
                        <thead>
                            <tr>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Section</th>
                                <th>Semester</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {courses
                                .filter(course => !myCourses.find(mc => mc._id === course._id))
                                .map(course => (
                                    <tr key={course._id}>
                                        <td>{course.courseCode}</td>
                                        <td>{course.courseName}</td>
                                        <td>{course.section}</td>
                                        <td>{course.semester}</td>
                                        <td>
                                            <Button 
                                                variant="success" 
                                                size="sm" 
                                                onClick={() => handleEnroll(course._id)}
                                            >
                                                Enroll
                                            </Button>
                                        </td>
                                    </tr>
                                ))}
                        </tbody>
                    </Table>
                </Card.Body>
            </Card>
            <EditModal />
        </Container>
    );
};

export default CourseList;