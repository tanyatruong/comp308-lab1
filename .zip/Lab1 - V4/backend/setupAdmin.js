const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Student = require('./models/Student');
require('dotenv').config();

const createAdminUser = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });

        // Check if admin already exists
        const adminExists = await Student.findOne({ email: 'admin@mycentennialcollege.ca' });
        
        if (adminExists) {
            console.log('Admin user already exists');
            // Update admin password if needed
            const hashedPassword = await bcrypt.hash('password', 10);
            await Student.findByIdAndUpdate(adminExists._id, { password: hashedPassword });
            console.log('Admin password updated');
        } else {
            // Create admin user
            const hashedPassword = await bcrypt.hash('password', 10);
            await Student.create({
                studentNumber: 'ADMIN001',
                firstName: 'Admin',
                lastName: 'User',
                email: 'admin@mycentennialcollege.ca',
                password: hashedPassword,
                program: 'Administration',
                favoriteTopic: 'System Management',
                strongestSkill: 'Administration'
            });
            console.log('Admin user created successfully');
        }

        console.log('Admin credentials:');
        console.log('Email: admin@mycentennialcollege.ca');
        console.log('Password: password');
        
        await mongoose.connection.close();
        process.exit(0);
    } catch (error) {
        console.error('Error creating admin user:', error);
        await mongoose.connection.close();
        process.exit(1);
    }
};

createAdminUser();